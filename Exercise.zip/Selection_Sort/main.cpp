// Selection sort -- another try

#include <iostream>
using namespace std;

void array_print(int* arr, int n)
{
    for(int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;
}

void selection_sort(int* arr, int n)
{
    for(int i = 0; i < n - 1; i++)
    {
        int key = i;

        for(int j = i + 1; j < n; j++)
            if(arr[j] < arr[key])
            {
                key = j;
            }

        swap(arr[i], arr[key]);
        // array_print(arr, n);
    }
}

//void selection_sort(int* arr, int n)
//{
//    for(int i = 0; i < n - 1; i++)
//    {
//        int key = i;
//        int min_value = arr[i];
//
//        for(int j = i + 1; j < n; j++)
//        {
//            if(arr[j] < min_value)
//            {
//                min_value = arr[j];
//                key = j;
//            }
//        }
//        swap(arr[i], arr[key]);
//    }
//}

// driver code
int main(void)
{
    int arr[] = {0, 9, 1, 35,2, 4, 3, 20, 17, 99};
    int n = sizeof arr / sizeof arr[0];

    array_print(arr, n);
    cout << endl;
    selection_sort(arr, n);
    array_print(arr, n);

    return 0;
}
