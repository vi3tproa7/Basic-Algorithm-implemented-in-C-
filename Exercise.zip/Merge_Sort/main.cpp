// A program to implement merge sort in C++
// This sort is a typical example of divide and conquer approach: divide, conquer and combine
// Actually, implementing merge sort in C/C++ is a little bit difficult because the array start from 0

#include <iostream>
#include <climits>
using namespace std;

// Prints the array
void array_Print(int a[], int n)
{
    for(int i = 0; i < n; i++)
        printf("%5d", a[i]);
    printf("\n");
}

// Merge procedure -- to merge 2 sorted sequences (2 piles of cards)
void merge_Procedure(int a[], int p, int q, int r)
{
    int n1 = q - p + 1;         // L will include q
    int n2 = r - q;             // R start from q + 1
    int L[n1 + 1];              // the number of elements is n1 + 1 but the last element will be L[n1]
    int R[n2 + 1];

    for(int i = 0; i < n1; i++) // i = 1st to n1-th
        L[i] = a[p + i];
    for(int j = 0; j < n2; j++)
        R[j] = a[q + j + 1];    // R start from q + 1 => a[q] // a start from 0
    L[n1] = INT_MAX;            // temporary solution for sentinel cards (using max int value)
    R[n2] = INT_MAX;            // without sentinel cards, the implementation of merge sort
                                // need 2 more loops to copy the remaining cards of the pile
    L[n1] = 999;
    R[n2] = 999;
     array_Print(L, n1 + 1);
     array_Print(R, n2 + 1);
    int i = 0;
    int j = 0;
    for(int k = p; k <= r; k++)  // oh, cost 15' to fix, k run from p to r
    {
        if(L[i] <= R[j])
        {
            a[k] = L[i];
            i++;
        }
        else
        {
            a[k] = R[j];
            j++;
        }
    }
}

// divide input array (recursively) until p >= r (when subarray has only 1 element) then merge
void MERGE_SORT(int a[], int p, int r)
{
    if(p < r)
    {
        int q = (p + r) / 2;
        MERGE_SORT(a, p, q);
        MERGE_SORT(a, q + 1, r);
        merge_Procedure(a, p, q, r);
    }
}

// Driver code
int main(void)
{
    int input_array[] = {2, 1, 6, 5, 15, 12, 9, 8};
    int n = sizeof input_array / sizeof input_array[0];

    cout << "The original sequence is:\n";
    array_Print(input_array, n);

    cout << "\nThe sequence after sorting by merge sort:\n";
    MERGE_SORT(input_array, 0, n - 1);
    array_Print(input_array, n);

    return 0;
}
