// Letter_Sort.cpp -- sorting letter

#include <iostream>
using namespace std;

void array_print(char* arr, int n)
{
    for(int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;
}

void bubble_sort(char* arr, int n)
{
    for(int i = 0; i < n - 1; i++)
        for(int j = 0; j < n - i - 1; j++)
            if(arr[j] > arr[j + 1])
                swap(arr[j], arr[j + 1]);
}
int main(void)
{
    char arr[] = {'a', 'c', 'b', 'z', 'm'};
    int n = sizeof arr / sizeof arr[0];

    array_print(arr, n);
    bubble_sort(arr, n);
    array_print(arr, n);

    return 0;
}
