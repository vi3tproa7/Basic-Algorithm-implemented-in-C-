// Quicksort -- in 2 different version

#include <iostream>
#include <chrono>
using namespace std;
using namespace std::chrono;

void array_print(int arr[], int n)
{
    for(int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;
}

int partition(int arr[], int p, int r)
{
    int pivot = arr[r];
    int i = p - 1;

    for(int j = p; j <= r - 1; j++)
    {

        if(arr[j] <= pivot)
        {
            i++;
            swap(arr[j], arr[i]);
        }
    }
    swap(arr[i + 1], arr[r]);

    return  (i + 1);
}

int partition_1(int arr[], int p, int r)
{
    int pivot = arr[r];
    int left = p;
    int right = r - 1;

    while(true)
    {
        while(left <= right && arr[left] < pivot) left++;
        while(right >= left && arr[right] > pivot) right--;

        if(left >= right)
            break;

        swap(arr[left], arr[right]);
        left++;
        right--;
    }
    swap(arr[left], arr[r]);
    return left;
}

void quick_sort(int arr[], int p, int r)
{
    if(p < r)
    {
        int q = partition_1(arr, p, r);
        quick_sort(arr, p, q - 1);
        quick_sort(arr, q + 1, r);
    }
}



// driver code
int main(void)
{
    int input_array[] = {2, 1, 6, 5, 15, 12, 9, 8, 20};
    int n = sizeof input_array / sizeof input_array[0];

    cout << "The original sequence is:\n";
    array_print(input_array, n);

    cout << "\nThe sequence after sorting by quick sort:\n";
    quick_sort(input_array, 0, n - 1);
    array_print(input_array, n);

//    int arr[] = {1, 2, 3, 5, 4, 3};
//    int n = sizeof arr / sizeof arr[0];
//
//    auto start = high_resolution_clock::now();
//
//    array_print(arr, n);
//    quick_sort(arr, 0, n - 1);
//    array_print(arr, n);
//
//    auto stop = high_resolution_clock::now();
//    auto duration = duration_cast<microseconds>(stop - start);
//
//    cout << "Time taken by function: "
//         << duration.count() << " microseconds" << endl;

    return 0;
}
